# linux-multi-switching-mining-manager
Linux Multi Switching Mining Manager by Sorting Algorithmen and WATT Calkulations at best income. And for more Values for Energy cost(Grid, SolarPV,battery pack).
Only with bash scripts.
Initial Author: Avalonis

Needed commands:
---------------
curl
nvidia-smi (nvidia-cuda-drivers)
su -c "apt_get update ; apt-get install libnotify-bin"

Future Extensions:
-----------------
Switching miner/algo on GPU
Realtime conversion BitCoins to EUR
